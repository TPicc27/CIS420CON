﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CIS420CON.Models
{
    public class Admin
    {
        public int AdminId { get; set; }
    }
}