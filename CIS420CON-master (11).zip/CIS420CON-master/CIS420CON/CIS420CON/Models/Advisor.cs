﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CIS420CON.Models
{
    public class Advisor
    {
        public int AdvisorId { get; set; }
    }
}